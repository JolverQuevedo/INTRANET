
select * from specs_head
select * from specs_GRUPOS
select * from specs_MEDIDAS

 DELETE specs_MEDIDAS
 DELETE specs_GRUPOS
 DELETE specs_head
