drop table tempos
go
CREATE TABLE [dbo].[tempos](
	 [NUMORD]	char(13),
	 [PO]		CHAR(20),
	 [UBI]		INT ,
	 [CANT]		INT ) 
go
select * from tempos
