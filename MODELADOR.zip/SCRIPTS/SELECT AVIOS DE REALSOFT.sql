select * from RSFACCAR..AL0001ARTI
where ar_cgrupo in ('AC','ET','EM','BL','BO','CR','EL','EN','ET','HL','MB','HG')

