SELECT * FROM INFORMATION_SCHEMA.TABLES where TABLE_TYPE='base table' order by table_name
-- select * from RS_ALMOVC_Del0001

--drop table guiamarisa
--drop table pos0001
--drop table PARTE_ENTRADA
-- delete RS_ALMOVC_Del0001 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete RS_ALMOVC_Del0002 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete RS_ALMOVC_Del0006 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete RS_ALMOVC_Del0008 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete RS_ALMOVC_Del0012 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete po_movi where fecha<=CONVERT(DATETIME,'31/12/2016',103) 



-- delete RS_ALMOVC_Del0005 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete RS_ALMOVC_Del0006 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 
-- delete RS_ALMOVC_Del0007 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 


-- delete RS_ALMOVC_Del0012 where c5_dfecdoc<=CONVERT(DATETIME,'31/12/2016',103) 


