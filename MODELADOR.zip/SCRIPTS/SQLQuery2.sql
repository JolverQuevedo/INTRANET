SELECT     *  FROM   dbo.RS_ALMOVD
WHERE     lote like '%10170%' and (ESTADO = 'V') AND (CTD = 'PE') AND (VBCC = 'S') AND (CALMA = '00MT')