
delete cotihilado where cotizacion like '%1593'
delete COTIRUTA where cotizacion like '%1593'
delete [COTI-TENIDO] where cotizacion like '%1593'
 delete cotizacion where cotizacion like '%1599'
update protos set cotizacion = null where cotizacion like '%1593'
