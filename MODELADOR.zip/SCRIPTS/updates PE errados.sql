update   RSFACCAR..al0001movd 
set c6_ccodigo = '600000059900020' 	
WHERE c6_cnumdoc = '00018701506'  AND c6_citem = '0003'  