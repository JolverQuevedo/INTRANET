/*SELECT * FROM --DELETE 
SERVICAB where numord = 'APR-2018-0003' 
SELECT * FROM --DELETE 
SERVIDET 
where numord = 'APR-2018-0003' */
--exec SP_SERVI_HEAD 'APR-2018-0003'
--select codest, temporada from view_pos where po = (select top 1 po from servidet where numord= 'APR-2018-0001')

 SELECT dd.po as pos, dd.ubi as uu, tot105, dd.color
 from View_Cliente_Temporada_Estilo_PO_color as dd 
 full outer join servidet as ss on ss.po = dd.po 
 WHERE CLIENTE = '00001' and codtem = '033' and estilo = '00006' and color = 'BLACK09' and LEFT(NUMORD,3) = 'APR'

  SELECT dd.po as pos, dd.ubi as uu, sum(tot105) as tot105, dd.color, isnull(sum(cant),0) as qty , numord
 from View_Cliente_Temporada_Estilo_PO_color as dd 
 full outer join servidet as ss on ss.po = dd.po 
 WHERE CLIENTE = '00001' and codtem = '033' and estilo = '00006' and color = 'BLACK09' and numord <>  'APR-2018-0001'
 group by numord, dd.po, dd.ubi, dd.color